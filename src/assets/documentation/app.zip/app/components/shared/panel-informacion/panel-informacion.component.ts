import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panel-informacion',
  templateUrl: './panel-informacion.component.html'
})
export class PanelInformacionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
