

export const URL_SERVICIOS = 'http://172.24.33.71:9081/api2/v1/documentos';
