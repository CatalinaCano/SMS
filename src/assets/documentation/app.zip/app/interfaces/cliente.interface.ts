export interface Cliente {
    razonSocial: string;
    codigoCliente: string;
}
