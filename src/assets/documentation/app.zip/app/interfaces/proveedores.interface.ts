export interface Proveedores {
    nombreProveedor: string;
    codigoProveedor: string;
}
