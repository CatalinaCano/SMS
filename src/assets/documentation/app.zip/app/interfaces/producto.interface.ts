export interface Producto {
    codigoProducto: string;
    descripcionProducto: string;
}
