

export  interface Ordenes {
    numOrden: string;
}
